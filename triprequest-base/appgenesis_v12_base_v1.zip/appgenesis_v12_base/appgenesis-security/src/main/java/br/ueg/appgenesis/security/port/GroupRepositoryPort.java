package br.ueg.appgenesis.security.port;

import br.ueg.appgenesis.core.port.GenericRepositoryPort;
import br.ueg.appgenesis.security.domain.Group;

public interface GroupRepositoryPort extends GenericRepositoryPort<Group, Long> {
}
