package br.ueg.appgenesis.security.domain.link;

import lombok.Value;

@Value
public class UserGroup {
    Long userId;
    Long groupId;
}
