package br.ueg.appgenesis.core.security;
public interface ActionKey { String name(); }
