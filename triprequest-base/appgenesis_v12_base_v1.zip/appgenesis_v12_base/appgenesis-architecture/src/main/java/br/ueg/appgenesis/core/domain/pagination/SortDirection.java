package br.ueg.appgenesis.core.domain.pagination;

public enum SortDirection {
    ASC,
    DESC
}