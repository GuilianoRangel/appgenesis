package br.ueg.appgenesis.core.security;
public enum CrudAction implements ActionKey { CREATE, READ, UPDATE, PATCH, DELETE, LIST }
